/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		long n = sc.nextLong();
		System.out.println(countDigits(n));
	}
	public static int countDigits(long n) {
		if (n < 10) return 1;
		return 1 + countDigits(n / 10);
	}
}
